package com.cg.emp.junit;

import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.HashMap;





import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.emp.dao.EmployeeDao;
import com.cg.emp.dao.EmployeeDaoImpl;
import com.cg.emp.entity.Employee;
import com.cg.emp.exception.EmployeeException;


public class TestCase {
	static EmployeeDao edao=null; 
	@BeforeClass
		public static void setUp()
		{
			edao=new EmployeeDaoImpl();
		} 
	@Test
public void addEmpTest() throws EmployeeException{


	} 
}

